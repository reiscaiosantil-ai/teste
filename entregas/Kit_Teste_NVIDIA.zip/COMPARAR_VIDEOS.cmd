@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "ROV_PYTHON="
if exist "runtime\python.exe" set "ROV_PYTHON=runtime\python.exe"
if not defined ROV_PYTHON if exist ".venv\Scripts\python.exe" set "ROV_PYTHON=.venv\Scripts\python.exe"
if not defined ROV_PYTHON (
    echo Copie este kit para a pasta do ROV Live que contem a pasta runtime.
    pause
    exit /b 1
)
echo Arraste cada video para esta janela e pressione Enter.
set /p "V1=1) Video ORIGINAL: "
set /p "V2=2) Video tratado pela NVIDIA: "
set /p "V3=3) Video exportado pelo ROV Live (Enter se nao tiver): "
if not exist logs mkdir logs
if defined V3 (
    "%ROV_PYTHON%" -u comparar_videos.py %V1% %V2% %V3% --nomes Original NVIDIA "ROV Live" --saida logs\comparacao_nvidia.mp4
) else (
    "%ROV_PYTHON%" -u comparar_videos.py %V1% %V2% --nomes Original NVIDIA --saida logs\comparacao_nvidia.mp4
)
echo.
echo Resultado em logs\comparacao_nvidia.mp4 e PNGs ao lado. Envie esses arquivos.
pause
