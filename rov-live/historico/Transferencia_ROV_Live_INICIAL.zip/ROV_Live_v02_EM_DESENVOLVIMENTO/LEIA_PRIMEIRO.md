# ROV Live — versão 0.2

Aplicativo desktop para receber vídeo de uma placa de captura ou câmera, aplicar
melhoria de imagem continuamente e comparar a imagem original com a tratada.
Interface em português. Feito para começar a testar o vídeo dos ROVs da Underwater.

**Esta entrega é um protótipo funcional com código-fonte e instalador de dependências
para Windows; não é um executável .exe pronto nem uma réplica da Orphiecam.**

## Atualizar quem já usa a versão 0.1

Feche o programa. Extraia o ZIP e copie os arquivos de dentro de `ROV_Live` para
**a mesma pasta onde está o INICIAR.cmd antigo**, substituindo os arquivos de mesmo
nome. Mantenha a pasta `.venv` que já existe: as dependências não mudaram. Abra
INICIAR.cmd novamente. Não é necessário reinstalar Python ou as dependências.

Na versão 0.2, comece com **Água turva**, intensidade **100%**, redução de névoa
**80%** e clareamento **0**. O perfil **Névoa forte** usa **95%**; ele amplifica mais
os contornos, mas também partículas, ruído e blocos de compressão. Segure
**Segure: ver original** para comparar no mesmo painel. Para baixa luz com pouca
névoa, use **Suave / pouca névoa**. Alterar um controle personaliza o perfil atual;
“Reaplicar perfil selecionado” restaura seus valores.

## Instalação no Windows

1. Extraia **todo o ZIP** para uma pasta sua, como `Documentos\ROV_Live`. Não execute de dentro do ZIP.
2. Instale **Python 3.12 de 64 bits** pelo site oficial, se ainda não tiver:
   https://www.python.org/downloads/release/python-31210/
   Escolha **Windows installer (64-bit)** e marque **Add python.exe to PATH**. Python 3.11 também é reconhecido pelo instalador.
3. Dê dois cliques em **INSTALAR.cmd**. Ele cria um ambiente `.venv` nessa pasta
   e baixa as dependências. É necessário acesso à internet nesta etapa; não precisa de administrador.
4. Quando aparecer “Pronto”, abra **INICIAR.cmd**.

O programa funciona localmente depois de instalado. Não faz upload do vídeo nem
usa serviços de IA. Fluxos IP naturalmente exigem conexão com a câmera correspondente.
Não mova apenas o `.venv`: se mudar a pasta, apague somente a pasta `.venv` e rode
INSTALAR.cmd novamente. Guarde os seus vídeos fora dela.

## Primeiro teste com a captura

1. Mantenha a saída original de pilotagem disponível. Teste primeiro em bancada.
2. Ligue a saída de vídeo da câmera/ROV à entrada compatível da placa de captura;
   conecte a captura ao computador e instale o driver do fabricante, se necessário.
3. Feche OBS, Teams, software de gravação e outros programas que possam estar usando a captura.
4. Em ROV Live, selecione **Placa de captura / câmera**, **Dispositivo 0**, **DirectShow**,
   resolução **1280 × 720**, **30 FPS** e formato **Auto**.
5. Clique em **Conectar**. Se aparecer uma webcam, teste os índices 1, 2, 3…
   Os índices representam a ordem do backend; podem mudar ao reconectar USB.
6. Se não abrir, tente **Media Foundation**, **Automático**, depois **MJPG** ou **YUY2**.
   O índice do mesmo dispositivo pode mudar entre backends.
7. Ajuste a intensidade e compare objetos reais. Use Espaço para desligar o filtro.

O aplicativo recebe apenas vídeo. Não envia comandos aos motores, manipuladores,
iluminação ou demais controles do ROV. A integração não precisa alterar o firmware
do veículo. A conexão física depende das interfaces disponíveis: não conecte HDMI
diretamente em SDI ou vídeo composto sem um conversor apropriado.

Capturas reconhecidas como dispositivos de vídeo por DirectShow/Media Foundation
são a primeira opção. Equipamentos que só funcionam pelo SDK proprietário podem
exigir um adaptador de software adicional. Não foi possível testar a placa física
da Underwater remotamente.

## Testar sem conectar o ROV

Selecione **Arquivo de vídeo**, clique em **Escolher vídeo…**, escolha MP4/AVI/MKV
e conecte. A reprodução respeita os timestamps quando disponíveis, com fallback
para FPS. “Repetir arquivo de teste” reinicia o vídeo no final. O áudio é ignorado.

Também existe entrada **Fluxo IP (RTSP / HTTP)**. Informe a URL direta do vídeo,
não a página web do dispositivo. RTSP usa TCP. O endereço é ocultado na interface
e não é salvo nas preferências. Não há ONVIF, descoberta automática de rede ou
autenticação por navegador nesta versão.

## O que os controles fazem

| Controle | Efeito |
|---|---|
| Intensidade | Mistura entre imagem original e filtrada. 0% preserva o original. |
| Clareamento | Curva de brilho para revelar regiões escuras; não muda a exposição física da câmera. |
| Correção de cor | Compensação limitada da dominante de cor, estimada na imagem. Não é calibração colorimétrica. |
| Contraste local | CLAHE na luminância. Pode amplificar ruído. |
| Redução de névoa | Estimativa de transmissão pelos canais azul/verde, refinada por filtro guiado. Ativa em 80% no perfil Água turva. Pode ampliar ruído, halos e erros de cor. |
| Redução de ruído | Filtro bilateral espacial. Mais lento; pode apagar detalhes pequenos. |

A redução de névoa é aplicada antes dos ajustes de brilho/cor. A correção de cor e a estimativa de névoa variam suavemente no tempo; cortes grandes de cena reiniciam as estimativas. Os pixels
de quadros diferentes não são misturados; não há interpolação de movimento nem
geração de quadros. Mudanças de cena ainda podem exigir ajuste manual.

O modo Original mostra o quadro recebido após eventual redução de resolução,
sem filtros de melhoria. Não é acesso RAW do sensor. A correção de cor, contraste
e névoa altera valores de pixels e deve ser conferida com o original para inspeção.

**A versão 0.2 usa CPU e OpenCV. Não usa CUDA, DLSS, redes neurais, treinamento ou
IA generativa.** Isso permite testar a integração sem saber o modelo da GPU.
Os 8 GB de VRAM não são utilizados nesta versão. Aceleração ou restauração por IA
deverá ser uma etapa posterior, com o modelo da placa e medições reais.

## Desempenho e atraso

- **Processados / FPS:** taxa recente de quadros tratados; a atualização leva cerca de meio segundo.
- **Filtro / ms:** tempo do filtro no quadro, excluindo captura, cópias e interface.
- **Idade no app / ms:** tempo desde que `VideoCapture.read()` entregou o quadro
  (ou desde a apresentação programada do arquivo) até a atualização da interface.
  **Não é a latência da câmera até o monitor.** Exclui atrasos internos da câmera,
  transmissão, buffers do driver e apresentação física do monitor.
- **Quadros pulados:** quadros mais antigos que o aplicativo não processou para
  acompanhar o mais recente. Não mede todas as perdas no driver ou na rede.
- O driver pode ignorar resolução, FPS, formato e pedido de buffer. A barra mostra
  as dimensões realmente recebidas e processadas. Arquivos não são ampliados.

Quando a CPU fica lenta, o aplicativo mantém um único quadro compartilhado e
prioriza o mais recente. O driver ainda pode ter buffers próprios. Para reduzir
custo, desligue ruído e névoa, reduza para 640 × 480 ou 720p e compare de novo.

Para medir atraso total em bancada, filme um relógio/marcador em movimento e
compare a cena real com a tela de saída, ou compare saída direta e tratada usando
uma câmera externa de alta taxa de quadros. Não use só o número de FPS como prova
de baixa latência. A aceitabilidade operacional precisa ser definida pela equipe.

## Perda de sinal e reconexão

Sem quadro recente por 0,75 s, o aplicativo retira a imagem e mostra um aviso.
Clique em **Reconectar** depois de corrigir a conexão. A captura roda em processo
separado, permitindo encerrar um driver travado sem travar o aplicativo indefinidamente.
A abertura sem nenhum quadro é encerrada após aproximadamente 15 segundos.

**Limite:** algumas capturas continuam enviando a mesma imagem congelada ou uma
tela “sem sinal”. Quadros chegando não comprovam que o sensor está atualizado.
Não há detecção confiável desse caso nesta versão. Não há reconexão automática.

## Interface e arquivos

- **Comparar / Somente tratada / Somente original:** escolha a visualização.
- **F11:** tela cheia; **Esc:** sair de tela cheia; **Espaço:** liga/desliga filtro.
- **Salvar comparação PNG:** salva original e tratada do mesmo quadro, lado a lado,
  no local escolhido. Não grava vídeo e não cria câmera virtual/saída SDI/HDMI dedicada.
  Para exibir em outro monitor, mova a janela para ele e use F11.
- **DIAGNOSTICO.cmd:** mostra nomes da GPU e dispositivos de imagem presentes.
  Não altera drivers nem envia dados. A lista do Windows não define os índices do OpenCV.

## Problemas comuns

| Sintoma | Ação |
|---|---|
| Não conecta | Feche outros programas; confira índice/backend; confira driver e permissões de câmera do Windows. |
| Tela preta com quadros chegando | Verifique sinal de entrada, formato PAL/NTSC ou resolução do conversor/captura; pode ser a própria captura produzindo preto. |
| Imagem verde/cores erradas | Tente Auto, MJPG ou YUY2 e o outro backend; verifique o conversor. |
| Muito atraso | Teste 720p, desligue ruído/névoa, compare com software do fabricante. |
| Muitos grãos | Reduza contraste/clareamento; avalie iluminação e distância do objeto. |
| Falha de instalação | Use Python de 64 bits, conexão ativa e pasta com permissão de escrita. Copie o erro exibido. |
| Instalar não encontra Python | Instale Python 3.12 x64 com PATH; feche e abra o instalador. |

## Desenvolvimento e validação

Arquivos principais: `app.py` (interface), `engine.py` (captura e processamento),
`processing.py` (filtros), `benchmark.py` (medição isolada do filtro), `test_rov.py` (testes).

Instalação manual: `python -m pip install -r requirements.txt`; execução: `python app.py`.
Para os testes: instale `pytest==8.3.5` e execute `python -m pytest -q test_rov.py`.
Para medir um trecho: `python benchmark.py "seu_video.mp4" --start 115 --frames 150`.

A validação desta entrega foi feita em Linux com Python 3.12, usando o vídeo
fornecido e testes sintéticos. Consulte `VALIDACAO.md` para resultados e limites.
Os scripts de instalação Windows foram revisados, mas não executados em Windows
neste ambiente. O teste com a captura real e o sistema de vocês continua necessário.

## Comparação incluída

`COMPARACAO_PRINT.png` mostra original, perfil Água turva e Névoa forte, calculados
a partir do painel ORIGINAL recortado do print enviado. É um teste estático em
imagem já redimensionada/comprimida; não demonstra o desempenho temporal do vídeo
novo, que não ficou acessível. Contornos antes fracos ficam mais evidentes, mas a
filtragem forte também enfatiza blocos e partículas. Não houve geração de conteúdo.

## Referências técnicas

- OpenCV — propriedades e limitações dos backends: https://docs.opencv.org/4.11.0/d4/d15/group__videoio__flags__base.html
- Qt for Python — QImage: https://doc.qt.io/qtforpython-6/PySide6/QtGui/QImage.html
- Qt for Python — QTimer: https://doc.qt.io/qtforpython-6/PySide6/QtCore/QTimer.html

O código próprio acompanha licença MIT. As dependências mantêm suas licenças:
NumPy (BSD), OpenCV (Apache 2.0 e componentes de terceiros) e PySide6/Qt (LGPL/GPL
ou licença comercial, conforme o componente). A instalação via pip conserva os
pacotes separados; eventual distribuição binária deve observar as licenças respectivas.

- Drews et al., Transmission Estimation in Underwater Single Images (UDCP): https://openaccess.thecvf.com/content_iccv_workshops_2013/W24/html/Drews_Jr._Transmission_Estimation_in_2013_ICCV_paper.html
- He et al., dark channel prior e guided filtering: https://people.csail.mit.edu/kaiming/cvpr09/

A implementação é própria, inspirada nessas técnicas. Não reproduz integralmente os artigos e não foi validada como equivalente à Orphiecam.
