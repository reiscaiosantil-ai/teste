# Validação da versão 0.1

Data: 28/10/2026. Ambiente de teste: Linux, Python 3.12.14, OpenCV 4.11.0,
NumPy 2.2.4, PySide6 6.8.3. CPU; OpenCV limitado a duas threads.

## Resultado

**12 testes automatizados passaram.**

- Bypass sem alterar pixels e processamento sem modificar o original.
- Quadros pretos, quase pretos, médios e brancos, incluindo névoa/ruído.
- Redimensionamento mantendo proporção e sem ampliar imagens menores.
- Reprodução de arquivo em ritmo real, captura e processamento separados.
- Encerramento de processo/thread, fim de arquivo e reconexão.
- Arquivo inexistente com falha controlada.
- Sobrecarga artificial do filtro: quadros antigos pulados sem fila crescente.
- Captura artificialmente travada: encerramento do processo sem espera indefinida.
- Interface: fonte, liga/desliga filtro e retirada da imagem sem quadro recente.

Interface Qt executada e inspecionada visualmente em modo offscreen, reproduzindo
um trecho derivado do vídeo enviado. Mostrou original e tratado, parâmetros,
dimensões e métricas. Compilação sintática dos módulos concluída sem erros.

## Medição com o vídeo fornecido

Trecho a partir de 115 s de `Meu primeiro vídeo(1).mp4`, 150 quadros medidos,
10 quadros de aquecimento, redução para 1280 × 720. Ajuste suave padrão;
névoa e redução de ruído desligadas. Execução isolada, após os demais testes.

| Medida | Resultado |
|---|---:|
| Mediana do tempo do filtro | 16,26 ms |
| Percentil 95 do tempo do filtro | 27,95 ms |
| Média de cinza antes | 23,66 / 255 |
| Média de cinza depois | 34,47 / 255 |

Esses tempos medem somente o filtro, excluindo leitura, decodificação,
transferências, redimensionamento, interface e monitor. **Não são medição de
latência total nem garantia de 30 FPS na máquina da Underwater.** A elevação
do brilho não comprova recuperação de detalhes. A imagem ficou mais clara no
trecho inspecionado; o ganho de identificação precisa ser validado pela equipe.

Durante execução simultânea com outros testes, houve tempos maiores, reforçando
que sobrecarga do computador afeta o resultado. O aplicativo permite medir o
comportamento na máquina real e reduzir resolução/efeitos quando necessário.

## Ainda não verificado

- Windows e scripts .cmd em execução real (revisão estática apenas).
- Placa de captura física, driver e sinal do ROV da Underwater.
- RTSP/HTTP com uma câmera física na rede da empresa.
- Latência de ponta a ponta, estabilidade em turnos longos, condições offshore.
- Inspeção de defeitos pequenos ou medições a partir da imagem tratada.

O pacote não inclui os vídeos do usuário, modelos de IA ou dependências binárias.
As dependências são baixadas durante a instalação. Não há aplicativo .exe pré-compilado.
