@echo off
setlocal
cd /d "%~dp0"
echo === Windows e placa de video ===
powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion | Format-List"
echo === Dispositivos Camera e Image ===
powershell -NoProfile -Command "Get-PnpDevice -PresentOnly | Where-Object { $_.Class -in @('Camera','Image') } | Select-Object Status,FriendlyName | Format-Table -AutoSize"
echo A lista do Windows nao determina a ordem dos indices do OpenCV.
if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -c "import sys, cv2, numpy; print(sys.version); print('OpenCV', cv2.__version__, 'NumPy', numpy.__version__)"
pause
