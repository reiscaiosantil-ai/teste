"""ROV Live 0.2 — local capture and underwater dehazing workstation."""
import os
os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
import argparse
import json
import multiprocessing as mp
from pathlib import Path
import sys
import time

import cv2
import numpy as np
from PySide6.QtCore import Qt, QTimer, QSettings
from PySide6.QtGui import QImage, QPixmap, QPainter, QColor, QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QFileDialog, QMessageBox, QCheckBox,
    QHBoxLayout, QVBoxLayout, QFormLayout, QGroupBox, QSplitter, QScrollArea)

from engine import Session, Source
from processing import Settings

STYLE = """
QWidget { background: #0b1420; color: #d9e6ef; font-family: 'Segoe UI'; font-size: 13px; }
QMainWindow { background: #0b1420; }
QLabel#brand { font-size: 25px; font-weight: 700; color: #ffffff; }
QLabel#sub { color: #8da7b8; }
QLabel#status { color: #65e0c5; padding: 9px; background: #122736; border-radius: 6px; }
QGroupBox { border: 1px solid #273e50; border-radius: 8px; margin-top: 16px; padding: 14px 10px 10px; font-weight: 600; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #83c6d1; }
QPushButton { background: #1c3549; border: 1px solid #34526a; border-radius: 6px; padding: 9px 12px; }
QPushButton:hover { background: #29475d; }
QPushButton#primary { background: #167b70; border-color: #28b69c; color: white; font-weight: 700; }
QPushButton:disabled { color: #526777; background: #142230; border-color: #223542; }
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { background: #122332; border: 1px solid #345063; border-radius: 5px; padding: 6px; }
QComboBox QAbstractItemView { selection-background-color: #236c70; }
QCheckBox { spacing: 8px; padding: 5px 0; }
QSplitter::handle { background: #1e3548; width: 3px; }
QToolTip { background: #20394e; color: white; border: 1px solid #4c758e; }
"""


class VideoPanel(QWidget):
    def __init__(self, title, accent):
        super().__init__()
        self.title, self.accent = title, accent
        self.image = None
        self.overlay = "Aguardando conexão"
        self.setMinimumSize(220, 200)

    def set_frame(self, frame):
        h, w = frame.shape[:2]
        self.image = QImage(frame.data, w, h, frame.strides[0], QImage.Format.Format_BGR888).copy()
        self.overlay = ""
        self.update()

    def clear_frame(self, message):
        self.image = None
        self.overlay = message
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#060d15"))
        view = self.rect().adjusted(8, 42, -8, -10)
        if self.image is not None:
            size = self.image.size().scaled(view.size(), Qt.AspectRatioMode.KeepAspectRatio)
            x, y = view.x() + (view.width() - size.width()) // 2, view.y() + (view.height() - size.height()) // 2
            painter.drawImage(x, y, self.image.scaled(size, Qt.AspectRatioMode.KeepAspectRatio,
                                                     Qt.TransformationMode.FastTransformation))
        painter.setPen(QColor(self.accent))
        painter.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        painter.drawText(14, 26, self.title)
        if self.overlay:
            painter.setPen(QColor("#8da7b8"))
            painter.setFont(QFont("Segoe UI", 12))
            painter.drawText(view, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.overlay)


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ROV Live • tratamento de vídeo ao vivo")
        self.resize(1440, 870)
        self.session = None
        self.last_sequence = -1
        self.current = None
        self.reference_held = False
        self.failed_open = False
        self.preferences = QSettings("ROVLive", "ROVLive")
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(20, 16, 20, 12)
        heading = QHBoxLayout()
        title = QLabel("ROV / LIVE")
        title.setObjectName("brand")
        heading.addWidget(title)
        subtitle = QLabel("Redução de névoa  •  Protótipo 0.2  •  CPU / local")
        subtitle.setObjectName("sub")
        heading.addWidget(subtitle)
        heading.addStretch()
        help_btn = QPushButton("Ajuda")
        help_btn.clicked.connect(self.show_help)
        heading.addWidget(help_btn)
        layout.addLayout(heading)
        self.status = QLabel("Conecte a captura ou abra um vídeo para começar.")
        self.status.setObjectName("status")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        body = QHBoxLayout()
        sidebar = QWidget()
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(0, 0, 6, 0)
        source_box = QGroupBox("01  /  Fonte de vídeo")
        form = QFormLayout(source_box)
        self.kind = QComboBox()
        self.kind.addItems(["Placa de captura / câmera", "Arquivo de vídeo", "Fluxo IP (RTSP / HTTP)"])
        self.kind.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.kind.setMinimumContentsLength(16)
        form.addRow("Entrada", self.kind)
        self.index = QSpinBox()
        self.index.setRange(0, 20)
        self.index.setValue(int(self.preferences.value("device_index", 0)))
        self.index.setToolTip("Índice do dispositivo no OpenCV. Teste 0, 1, 2… A webcam pode ser o índice 0.")
        form.addRow("Dispositivo", self.index)
        self.backend = QComboBox()
        self.backend.addItems(["DirectShow", "Media Foundation", "Automático"])
        form.addRow("Backend", self.backend)
        self.path = QLineEdit()
        self.path.setPlaceholderText("Selecione um arquivo ou informe a URL")
        form.addRow("Endereço", self.path)
        self.browse = QPushButton("Escolher vídeo…")
        self.browse.clicked.connect(self.choose_file)
        form.addRow(self.browse)
        self.resolution = QComboBox()
        self.resolution.addItems(["1280 × 720", "1920 × 1080", "640 × 480", "960 × 540"])
        form.addRow("Resolução", self.resolution)
        self.fps = QComboBox()
        self.fps.addItems(["30", "25", "60"])
        form.addRow("FPS solicitados", self.fps)
        self.fourcc = QComboBox()
        self.fourcc.addItems(["Auto", "MJPG", "YUY2"])
        form.addRow("Formato captura", self.fourcc)
        self.loop = QCheckBox("Repetir arquivo de teste")
        self.loop.setChecked(True)
        form.addRow(self.loop)
        self.start = QPushButton("Conectar")
        self.start.setObjectName("primary")
        self.start.clicked.connect(self.connect_source)
        self.stop = QPushButton("Desconectar")
        self.stop.setEnabled(False)
        self.stop.clicked.connect(self.disconnect)
        buttons = QHBoxLayout()
        buttons.addWidget(self.start)
        buttons.addWidget(self.stop)
        form.addRow(buttons)
        side.addWidget(source_box)
        treatment = QGroupBox("02  /  Tratamento")
        controls = QFormLayout(treatment)
        self.profile = QComboBox()
        self.profile.addItems(["Água turva", "Névoa forte", "Suave / pouca névoa"])
        controls.addRow("Perfil", self.profile)
        self.enabled = QCheckBox("Aplicar melhoria  [Espaço]")
        self.enabled.setChecked(True)
        controls.addRow(self.enabled)
        self.strength = self.number(0, 100, 100, 5, " %")
        self.exposure = self.number(-1, 2, 0, 0.1, "", 1)
        self.color = self.number(0, 100, 15, 5, " %")
        self.contrast = self.number(1, 3, 1.3, 0.1, "", 1)
        self.haze = self.number(0, 100, 80, 5, " %")
        self.haze.setToolTip("Comece em 80%. Aumentar pode revelar contornos, mas também ruído, halos e artefatos de compressão.")
        for label, widget in [("Intensidade", self.strength), ("Clareamento", self.exposure),
                ("Correção de cor", self.color), ("Contraste local", self.contrast), ("Redução de névoa", self.haze)]:
            controls.addRow(label, widget)
        self.denoise = QCheckBox("Redução de ruído (mais lenta)")
        controls.addRow(self.denoise)
        reset = QPushButton("Reaplicar perfil selecionado")
        reset.clicked.connect(self.reset_settings)
        controls.addRow(reset)
        for widget in [self.strength, self.exposure, self.color, self.contrast, self.haze]:
            widget.valueChanged.connect(self.update_settings)
        self.enabled.toggled.connect(self.update_settings)
        self.denoise.toggled.connect(self.update_settings)
        self.profile.currentIndexChanged.connect(self.reset_settings)
        side.addWidget(treatment)
        note = QLabel("Comece em 720p. Resolução e FPS são pedidos ao driver; o formato recebido pode ser diferente.")
        note.setWordWrap(True)
        note.setObjectName("sub")
        side.addWidget(note)
        side.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(sidebar)
        scroll.setMinimumWidth(375)
        scroll.setMaximumWidth(400)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body.addWidget(scroll)
        right = QVBoxLayout()
        toolbar = QHBoxLayout()
        self.view = QComboBox()
        self.view.addItems(["Comparar", "Somente tratada", "Somente original"])
        self.view.currentIndexChanged.connect(self.change_view)
        toolbar.addWidget(self.view)
        full = QPushButton("Tela cheia  [F11]")
        full.clicked.connect(self.toggle_fullscreen)
        toolbar.addWidget(full)
        reference = QPushButton("Segure: ver original")
        reference.pressed.connect(lambda: self.hold_original(True))
        reference.released.connect(lambda: self.hold_original(False))
        toolbar.addWidget(reference)
        toolbar.addStretch()
        self.snapshot_btn = QPushButton("Salvar comparação PNG")
        self.snapshot_btn.setEnabled(False)
        self.snapshot_btn.clicked.connect(self.save_snapshot)
        toolbar.addWidget(self.snapshot_btn)
        right.addLayout(toolbar)
        self.original = VideoPanel("ORIGINAL • sem tratamento", "#a9bdcd")
        self.enhanced = VideoPanel("TRATADA • filtros locais", "#65e0c5")
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self.original)
        splitter.addWidget(self.enhanced)
        right.addWidget(splitter, 1)
        self.metrics = QLabel("FPS: —   |   Filtro: — ms   |   Idade no app: — ms")
        self.metrics.setWordWrap(True)
        right.addWidget(self.metrics)
        explain = QLabel("Idade no app começa após a leitura do quadro. Não mede o atraso da câmera, do cabo, do driver ou do monitor.")
        explain.setObjectName("sub")
        explain.setWordWrap(True)
        right.addWidget(explain)
        body.addLayout(right, 1)
        layout.addLayout(body, 1)
        self.kind.currentIndexChanged.connect(self.source_visibility)
        self.source_visibility()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(16)
        QShortcut(QKeySequence("F11"), self, activated=self.toggle_fullscreen)
        QShortcut(QKeySequence("Escape"), self, activated=self.showNormal)
        QShortcut(QKeySequence("Space"), self, activated=self.enabled.toggle)

    @staticmethod
    def number(low, high, value, step, suffix, decimals=0):
        widget = QDoubleSpinBox()
        widget.setRange(low, high)
        widget.setDecimals(decimals)
        widget.setSingleStep(step)
        widget.setSuffix(suffix)
        widget.setValue(value)
        return widget

    def settings(self):
        return Settings(self.enabled.isChecked(), self.strength.value() / 100,
            self.exposure.value(), self.color.value() / 100, self.contrast.value(),
            self.haze.value() / 100, self.denoise.isChecked())

    def update_settings(self, *_):
        if self.session:
            self.session.settings = self.settings()

    def reset_settings(self, *_):
        self.enabled.setChecked(True)
        presets = [(100, 0, 15, 1.3, 80), (100, 0, 15, 1.2, 95), (65, .6, 35, 1.6, 0)]
        values = presets[self.profile.currentIndex()]
        for widget, value in zip([self.strength, self.exposure, self.color, self.contrast, self.haze], values):
            widget.setValue(value)
        self.denoise.setChecked(False)

    def source_visibility(self, *_):
        capture = self.kind.currentIndex() == 0
        for widget in [self.index, self.backend, self.fourcc]:
            widget.setEnabled(capture)
        self.path.setEnabled(not capture)
        self.path.setEchoMode(QLineEdit.EchoMode.Password if self.kind.currentIndex() == 2 else QLineEdit.EchoMode.Normal)
        self.browse.setEnabled(self.kind.currentIndex() == 1)
        self.loop.setEnabled(self.kind.currentIndex() == 1)

    def choose_file(self):
        name, _ = QFileDialog.getOpenFileName(self, "Abrir vídeo", "", "Vídeos (*.mp4 *.avi *.mkv *.mov *.m4v);;Todos (*)")
        if name:
            self.path.setText(name)

    def connect_source(self):
        kind = ["capture", "file", "stream"][self.kind.currentIndex()]
        value = str(self.index.value()) if kind == "capture" else self.path.text().strip()
        if kind == "file" and not Path(value).is_file():
            QMessageBox.warning(self, "Arquivo", "Selecione um arquivo de vídeo existente.")
            return
        if kind == "stream" and not value.lower().startswith(("rtsp://", "http://", "https://")):
            QMessageBox.warning(self, "Fluxo IP", "Informe uma URL RTSP, HTTP ou HTTPS do fluxo de vídeo.")
            return
        self.disconnect()
        w, h = [(1280, 720), (1920, 1080), (640, 480), (960, 540)][self.resolution.currentIndex()]
        source = Source(kind, value, self.backend.currentText(), w, h, int(self.fps.currentText()),
                        self.fourcc.currentText(), self.loop.isChecked())
        try:
            self.session = Session(source, self.settings())
        except Exception:
            QMessageBox.critical(self, "Inicialização", "Não foi possível iniciar a captura. Feche outros aplicativos de câmera e tente novamente.")
            return
        self.preferences.setValue("device_index", self.index.value())
        self.start.setText("Reconectar")
        self.stop.setEnabled(True)
        self.status.setText("Conectando… O primeiro quadro pode levar alguns segundos.")
        self.failed_open = False

    def disconnect(self):
        if self.session:
            self.session.close()
            self.session = None
        self.current = None
        self.last_sequence = -1
        self.stop.setEnabled(False)
        self.snapshot_btn.setEnabled(False)
        self.start.setText("Conectar")
        for panel in [self.original, self.enhanced]:
            panel.clear_frame("Sem conexão")
        self.status.setText("Desconectado. Selecione a fonte e clique em Conectar.")
        self.metrics.setText("FPS: —   |   Filtro: — ms   |   Idade no app: — ms")

    def refresh(self):
        if not self.session:
            return
        packet = self.session.snapshot()
        now = time.perf_counter()
        if packet is None:
            self.status.setText(self.session.message)
            if now - self.session.started > 15 and not self.failed_open:
                self.failed_open = True
                self.status.setText("Nenhum quadro recebido em 15 s. Confira o dispositivo/backend e clique em Reconectar.")
                self.session.close()
                self.session = None
                self.stop.setEnabled(False)
            return
        age = now - packet["received"]
        if age > 0.75:
            self.current = None
            self.snapshot_btn.setEnabled(False)
            for panel in [self.original, self.enhanced]:
                panel.clear_frame("SEM QUADRO RECENTE\nConfira o sinal e reconecte")
            self.metrics.setText(f"Sem quadro recente há {age:.1f} s. A imagem anterior foi retirada da tela.")
            self.status.setText(self.session.message if not self.session.process.is_alive() else "Sem atualização de vídeo. Fonte interrompida ou processamento sobrecarregado.")
            return
        if packet["seq"] == self.last_sequence:
            return
        self.last_sequence = packet["seq"]
        self.current = packet
        self.render_packet(packet)
        self.snapshot_btn.setEnabled(True)
        source_w, source_h = packet["source_size"]
        h, w = packet["original"].shape[:2]
        mode = "TESTE COM ARQUIVO" if self.session.source.kind == "file" else "CAPTURA AO VIVO"
        if packet.get("filter_error"):
            self.status.setText("ERRO NO FILTRO • Exibindo original nos dois painéis. Reconecte a fonte.")
            self.enhanced.title = "FILTRO INDISPONÍVEL • original"
        else:
            self.status.setText(f"{mode}  •  Entrada {source_w} × {source_h}  •  Processamento {w} × {h}")
        self.metrics.setText(f"Processados: {packet['fps']:.1f} FPS   |   Filtro: {packet['processing_ms']:.1f} ms   |   "
            f"Idade no app: {age * 1000:.0f} ms   |   Quadros pulados pelo app: {packet['skipped']}")

    def render_packet(self, packet):
        self.original.set_frame(packet["original"])
        self.enhanced.set_frame(packet["original"] if self.reference_held else packet["enhanced"])
        self.enhanced.title = "REFERÊNCIA • original" if self.reference_held else (
            "TRATADA • redução de névoa" if self.enabled.isChecked() else "TRATAMENTO DESLIGADO • original")

    def hold_original(self, held):
        self.reference_held = held
        if self.current and time.perf_counter() - self.current["received"] < .75:
            self.render_packet(self.current)

    def change_view(self, index):
        self.original.setVisible(index != 1)
        self.enhanced.setVisible(index != 2)

    def toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def save_snapshot(self):
        packet = self.current
        if packet is None or time.perf_counter() - packet["received"] > .75:
            return
        name, _ = QFileDialog.getSaveFileName(self, "Salvar comparação", "comparacao_rov.png", "PNG (*.png)")
        if not name:
            return
        if not name.lower().endswith(".png"):
            name += ".png"
        image = np.hstack([packet["original"], packet["enhanced"]])
        image = cv2.copyMakeBorder(image, 40, 0, 0, 0, cv2.BORDER_CONSTANT, value=(20, 14, 11))
        width = packet["original"].shape[1]
        for label, x in [("ORIGINAL", 12), ("TRATADA / FILTROS", width + 12)]:
            cv2.putText(image, label, (x, 27), cv2.FONT_HERSHEY_SIMPLEX, .65, (220, 235, 235), 1, cv2.LINE_AA)
        try:
            success, encoded = cv2.imencode(".png", image)
            if not success:
                raise OSError("encode")
            encoded.tofile(name)
        except OSError:
            QMessageBox.warning(self, "Salvar", "Não foi possível salvar. Escolha uma pasta com permissão de escrita.")

    def show_help(self):
        QMessageBox.information(self, "ROV Live • início rápido",
            "1. Feche OBS e outros programas que estejam usando a captura.\n"
            "2. Selecione Placa de captura, dispositivo 0 e DirectShow.\n"
            "3. Clique em Conectar. Se abrir a webcam, tente 1, 2…\n"
            "4. Se não abrir, tente Media Foundation ou formato MJPG.\n\n"
            "Use Arquivo de vídeo para testar sem o ROV.\n"
            "Comece pelo perfil Água turva, com redução de névoa em 80%.\n"
            "O perfil Névoa forte usa 95% e pode amplificar ruído/halos.\n"
            "Segure o botão de referência para comparar no mesmo painel.\n"
            "Espaço: liga/desliga o tratamento. F11: tela cheia.\n\n"
            "Esta versão usa CPU e filtros clássicos, sem IA generativa ou aceleração CUDA.\n"
            "A idade no app não é a latência total. A captura pode continuar enviando uma imagem congelada; "
            "a detecção de sinal verifica chegada de quadros, não comprova movimento da câmera.\n"
            "Valide em bancada e mantenha o monitor original de pilotagem disponível.\n"
            "Não grava vídeo, não envia dados à internet e não controla os movimentos do ROV.")

    def closeEvent(self, event):
        self.timer.stop()
        self.disconnect()
        event.accept()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", help="Abrir um arquivo de vídeo para teste")
    parser.add_argument("--screenshot", help=argparse.SUPPRESS)
    parser.add_argument("--quit-after", type=float, help=argparse.SUPPRESS)
    args = parser.parse_args()
    cv2.setNumThreads(2)
    app = QApplication(sys.argv[:1])
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    window = Window()
    window.show()
    if args.video:
        window.kind.setCurrentIndex(1)
        window.path.setText(args.video)
        QTimer.singleShot(200, window.connect_source)
    if args.screenshot:
        QTimer.singleShot(3500, lambda: window.grab().save(args.screenshot))
    if args.quit_after:
        QTimer.singleShot(int(args.quit_after * 1000), window.close)
    return app.exec()


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
