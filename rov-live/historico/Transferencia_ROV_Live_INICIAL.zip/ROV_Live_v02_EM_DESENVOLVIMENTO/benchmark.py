"""Measure filter CPU time on real frames, not end-to-end live latency."""
import argparse
import json
import time
from dataclasses import asdict
import cv2
import numpy as np
from engine import fit_frame
from processing import Enhancer, Settings


def benchmark(path, start=0, count=150, width=1280, height=720):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Não foi possível abrir o vídeo.")
    cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
    enhancer = Enhancer()
    samples = []
    luminance = []
    try:
        for index in range(count + 10):
            ok, frame = cap.read()
            if not ok:
                break
            frame = fit_frame(frame, width, height)
            t = time.perf_counter()
            output = enhancer.process(frame, Settings())
            elapsed = (time.perf_counter() - t) * 1000
            if index >= 10:
                samples.append(elapsed)
                luminance.append([float(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).mean()),
                                  float(cv2.cvtColor(output, cv2.COLOR_BGR2GRAY).mean())])
    finally:
        cap.release()
    if not samples:
        raise RuntimeError("Não há quadros suficientes nesse trecho.")
    return {"frames_measured": len(samples), "settings": asdict(Settings()), "resolution": [frame.shape[1], frame.shape[0]],
        "filter_ms_median": round(float(np.median(samples)), 2),
        "filter_ms_p95": round(float(np.percentile(samples, 95)), 2),
        "mean_gray_before_after": np.mean(luminance, axis=0).round(2).tolist(),
        "note": "CPU neste ambiente; exclui captura, decodificação, interface, monitor e latência total. Brilho não comprova recuperação de detalhes."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("--start", type=float, default=0)
    parser.add_argument("--frames", type=int, default=150)
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    args = parser.parse_args()
    cv2.setNumThreads(2)
    print(json.dumps(benchmark(args.video, args.start, args.frames, args.width, args.height), ensure_ascii=False, indent=2))
